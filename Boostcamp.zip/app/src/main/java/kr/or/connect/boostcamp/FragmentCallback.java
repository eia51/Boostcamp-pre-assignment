package kr.or.connect.boostcamp;

public interface FragmentCallback {
    public void setTitleText(String title);
}
